package com.wdiscute.starcatcher.guide;

import net.minecraft.world.item.Item;

public class FishingGuideItem extends Item {
    public FishingGuideItem() {
        super(new Item.Properties().stacksTo(1));
    }
}
