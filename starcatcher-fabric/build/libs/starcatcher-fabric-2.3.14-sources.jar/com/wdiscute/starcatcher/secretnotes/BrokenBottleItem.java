package com.wdiscute.starcatcher.secretnotes;

import net.minecraft.world.item.Item;

public class BrokenBottleItem extends Item {
    public BrokenBottleItem() {
        super(new Item.Properties().stacksTo(1));
    }
}
