package com.wdiscute.starcatcher.secretnotes;

import net.minecraft.world.item.Item;

public class BottledLetterItem extends Item {
    public BottledLetterItem() {
        super(new Item.Properties().stacksTo(1));
    }
}
