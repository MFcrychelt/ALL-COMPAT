package com.wdiscute.starcatcher.registry.items;

import net.minecraft.world.item.Item;

public class NoteContainer extends Item {
    public NoteContainer(Object... args) {
        super(new Item.Properties().stacksTo(1));
    }
}
