package com.wdiscute.starcatcher.registry.items;

import net.minecraft.world.item.Item;

public class WaterloggedSatchel extends Item {
    public WaterloggedSatchel() {
        super(new Item.Properties().stacksTo(1));
    }
}
