package com.wdiscute.starcatcher.registry.items;

import net.minecraft.world.item.Item;

public class FishItem extends Item {
    public FishItem() {
        super(new Item.Properties().food(SCFoodProperties.BASIC_RAW_FISH));
    }
}
